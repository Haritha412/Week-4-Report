# Submission Checklist

1. Upload `reports/Week_4_AI_Project_Report.docx` to the internship portal.
2. Create a GitHub repository and upload the entire project folder.
3. Paste the real GitHub repository URL into the portal's GitHub Project URL field.
4. In the report description field, you can use the short text below:

> This project is an end-to-end Iris Flower Classification machine-learning application.
> It includes dataset preparation, preprocessing with StandardScaler, Logistic Regression
> model training and evaluation, Joblib model serialization, a FastAPI prediction API,
> a browser-based interface, automated API tests, documentation, and Docker deployment
> configuration. The model was evaluated on a stratified held-out test set and achieved
> 93.33% accuracy. The API exposes health and prediction endpoints and provides
> interactive Swagger documentation. The complete source code, model artifact, dataset,
> requirements, tests, and README are included in the GitHub repository.
