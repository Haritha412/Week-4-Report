from pathlib import Path
import joblib
import pandas as pd
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "model" / "iris_model.joblib"
model = joblib.load(MODEL_PATH)

app = FastAPI(
    title="Iris Flower Classification API",
    version="1.0.0",
    description="Predicts iris species from four flower measurements."
)

class IrisInput(BaseModel):
    sepal_length: float = Field(..., gt=0, description="Sepal length in cm")
    sepal_width: float = Field(..., gt=0, description="Sepal width in cm")
    petal_length: float = Field(..., gt=0, description="Petal length in cm")
    petal_width: float = Field(..., gt=0, description="Petal width in cm")

@app.get("/", response_class=HTMLResponse)
def home():
    html = (ROOT / "templates" / "index.html").read_text()
    return HTMLResponse(html)

@app.get("/health")
def health():
    return {"status": "ok", "model": "iris_model.joblib"}

@app.post("/predict")
def predict(payload: IrisInput):
    row = pd.DataFrame([{
        "sepal length (cm)": payload.sepal_length,
        "sepal width (cm)": payload.sepal_width,
        "petal length (cm)": payload.petal_length,
        "petal width (cm)": payload.petal_width,
    }])
    prediction = model.predict(row)[0]
    probabilities = model.predict_proba(row)[0]
    classes = model.classes_
    confidence = float(max(probabilities))
    return {
        "prediction": str(prediction),
        "confidence": round(confidence, 4),
        "probabilities": {
            str(c): round(float(p), 4) for c, p in zip(classes, probabilities)
        }
    }
