from pathlib import Path
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
model = joblib.load(ROOT / "model" / "iris_model.joblib")

row = pd.DataFrame([{
    "sepal length (cm)": 5.1,
    "sepal width (cm)": 3.5,
    "petal length (cm)": 1.4,
    "petal width (cm)": 0.2,
}])

print("Prediction:", model.predict(row)[0])
print("Probabilities:", dict(zip(model.classes_, model.predict_proba(row)[0])))
