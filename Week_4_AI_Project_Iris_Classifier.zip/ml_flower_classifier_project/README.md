# Iris Flower Classification — End-to-End ML Deployment Project

A complete machine-learning project for the Week 4 AI Project Deployment & Capstone task.

## Objective
Build an end-to-end ML application covering data preparation, model training/testing,
model serialization, a prediction API, a browser UI, tests, and deployment packaging.

## Model
- Dataset: Iris dataset (150 observations, 4 numerical features, 3 classes)
- Preprocessing: StandardScaler
- Algorithm: Logistic Regression
- Test split: 20%, stratified
- Random state: 42
- Test accuracy: 0.9333 (93.33%)

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000 for the web interface.
Open http://127.0.0.1:8000/docs for Swagger API documentation.

## Test
```bash
pytest -q
```

## Docker
```bash
docker build -t iris-classifier .
docker run -p 8000:8000 iris-classifier
```

## API example
POST `/predict`
```json
{
  "sepal_length": 5.1,
  "sepal_width": 3.5,
  "petal_length": 1.4,
  "petal_width": 0.2
}
```

## Project structure
- `data/iris.csv` — project dataset
- `app/main.py` — FastAPI application
- `model/iris_model.joblib` — serialized trained model
- `tests/test_api.py` — API tests
- `templates/index.html` — browser interface
- `Dockerfile` — container deployment configuration
- `reports/metrics.json` — evaluation metrics

## GitHub
Create a GitHub repository and upload this folder. Use the resulting repository URL
in the internship submission form.
